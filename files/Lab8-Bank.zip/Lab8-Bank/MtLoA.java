
// Represents the empty List of Accounts
public class MtLoA implements ILoA{
    
    MtLoA(){}
}

