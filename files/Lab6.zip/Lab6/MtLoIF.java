
// Represents an empty list of ImageFiles
class MtLoIF implements ILoIF {

    MtLoIF() { }

    // Does this empty list contain that ImageFile   
    public boolean contains(ImageFile that) { 
        return false;
    } 
} 
