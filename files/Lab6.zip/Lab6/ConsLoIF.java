
// Represents a nonempty list of ImageFiles
public class ConsLoIF implements ILoIF {

    public ImageFile first;
    public ILoIF rest;

    public ConsLoIF(ImageFile first, ILoIF rest) {
        this.first=first;
        this.rest=rest;
    }

    // Does this nonempty list contain that ImageFile   
    public boolean contains(ImageFile that) { 
        return (this.first.sameImageFile(that) ||
                this.rest.contains(that));
    } 
}
